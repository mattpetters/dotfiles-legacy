This is a mirror of http://www.vim.org/scripts/script.php?script_id=2465

This is a version of Wombat (vimscript #1778) by Lars Nielsen that also works on xterms with 256 colors.

A customized version is also available, with additional highlighting groups for diff mode and search.
